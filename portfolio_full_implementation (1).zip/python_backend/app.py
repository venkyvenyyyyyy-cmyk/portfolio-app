
from flask import Flask, request, jsonify, g
import sqlite3
import os
import datetime

DB_PATH = os.environ.get("PORTFOLIO_DB", "portfolio_backend.db")

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.executescript('''
    CREATE TABLE IF NOT EXISTS assets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_type TEXT NOT NULL,
        identifier TEXT NOT NULL,
        name TEXT,
        units REAL DEFAULT 0,
        purchase_date TEXT,
        purchase_price REAL DEFAULT 0,
        metadata TEXT DEFAULT '{}'
    );
    CREATE TABLE IF NOT EXISTS price_cache (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_id INTEGER,
        fetched_at TEXT,
        price REAL,
        raw TEXT
    );
    ''')
    conn.commit()
    conn.close()

# simple in-memory last-price map (for demo)
_last_price_map = {}

app = Flask(__name__)

@app.before_first_request
def setup():
    init_db()

@app.route("/assets", methods=["GET","POST"])
def assets():
    conn = get_conn()
    cur = conn.cursor()
    if request.method == "GET":
        rows = cur.execute("SELECT * FROM assets ORDER BY id DESC").fetchall()
        res = [dict(r) for r in rows]
        return jsonify(res)
    else:
        data = request.get_json() or request.form.to_dict()
        cur.execute("INSERT INTO assets (asset_type, identifier, name, units, purchase_date, purchase_price, metadata) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (data.get("type"), data.get("identifier"), data.get("name"), float(data.get("units",0)), data.get("purchaseDate"), float(data.get("purchasePrice",0)), data.get("metadata","{}")))
        conn.commit()
        return jsonify({"ok":True}), 201

@app.route("/prices", methods=["GET"])
def prices():
    # Expects query param ids=comma,separated identifiers (identifiers are ticker or mfid)
    ids = request.args.get("ids","")
    identifiers = [i.strip() for i in ids.split(",") if i.strip()]
    result = {}
    # For demo, return deterministic dummy prices or previously cached _last_price_map
    for ident in identifiers:
        if ident in _last_price_map:
            price = _last_price_map[ident]
        else:
            # simple fake price based on hash
            price = (abs(hash(ident)) % 5000) + 50
            _last_price_map[ident] = price
        result[ident] = {"price": price, "fetched_at": datetime.datetime.utcnow().isoformat()}
    return jsonify(result)

@app.route("/sync/push", methods=["POST"])
def sync_push():
    # Accepts payload with assets/transactions; here we just upsert assets into backend DB for demo
    payload = request.get_json() or {}
    assets = payload.get("assets", [])
    conn = get_conn()
    cur = conn.cursor()
    for a in assets:
        # naive insert - no dedupe
        cur.execute("INSERT INTO assets (asset_type, identifier, name, units, purchase_date, purchase_price, metadata) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (a.get("type"), a.get("identifier"), a.get("name"), float(a.get("units",0)), a.get("purchaseDate"), float(a.get("purchasePrice",0)), a.get("metadata","{}")))
    conn.commit()
    return jsonify({"ok":True, "received": len(assets)})

@app.route("/sync/pull", methods=["GET"])
def sync_pull():
    # Return all assets as the source of truth
    conn = get_conn()
    cur = conn.cursor()
    rows = cur.execute("SELECT * FROM assets ORDER BY id DESC").fetchall()
    res = [dict(r) for r in rows]
    return jsonify({"assets": res})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
