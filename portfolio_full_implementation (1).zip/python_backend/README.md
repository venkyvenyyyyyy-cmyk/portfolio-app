
Python Flask backend for portfolio tracker (demo).
Run:
    pip install -r requirements.txt
    python app.py
The server starts on port 5000 and exposes:
  GET/POST /assets
  GET /prices?ids=ID1,ID2
  POST /sync/push
  GET /sync/pull
This is a demo server returning deterministic fake prices; replace with real fetchers (yfinance, mfapi) for production.
