import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/local_db.dart';
import 'asset_list.dart';
import 'add_asset.dart';
import 'chart_screen.dart';
import '../services/price_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  Widget build(BuildContext context) {
    final priceService = Provider.of<PriceService>(context, listen: false);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Portfolio'),
        actions: [
          IconButton(onPressed: () async { await priceService.updateAllPrices(context); }, icon: const Icon(Icons.sync)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: const [
            _SummaryCard(),
            SizedBox(height: 12),
            Expanded(child: AssetList()),
            SizedBox(height: 12),
            SizedBox(height: 180, child: ChartScreen()),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AddAssetScreen())),
        child: const Icon(Icons.add),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
            Text('Total Value', style: TextStyle(fontSize: 14, color: Colors.grey)),
            SizedBox(height: 8),
            Text('₹ 0.00', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 4),
            Text('+0.00 (0.00%)', style: TextStyle(fontSize: 12, color: Colors.green)),
          ])),
          const Icon(Icons.pie_chart_outline, size: 48, color: Colors.indigo),
        ]),
      ),
    );
  }
}
