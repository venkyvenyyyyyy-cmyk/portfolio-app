import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/local_db.dart';

class AddAssetScreen extends StatefulWidget {
  const AddAssetScreen({super.key});

  @override
  State<AddAssetScreen> createState() => _AddAssetScreenState();
}

class _AddAssetScreenState extends State<AddAssetScreen> {
  final _formKey = GlobalKey<FormState>();
  String type = 'stock';
  final identifierCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final unitsCtrl = TextEditingController();
  final priceCtrl = TextEditingController();

  @override
  void dispose() {
    identifierCtrl.dispose();
    nameCtrl.dispose();
    unitsCtrl.dispose();
    priceCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final db = Provider.of<LocalDb>(context, listen: false);
    await db.insertAsset({
      'type': type,
      'identifier': identifierCtrl.text.trim(),
      'name': nameCtrl.text.trim(),
      'units': double.tryParse(unitsCtrl.text) ?? 0,
      'purchasePrice': double.tryParse(priceCtrl.text) ?? 0,
      'purchaseDate': DateTime.now().toIso8601String(),
      'metadata': '{}',
    });
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Asset')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              DropdownButtonFormField<String>(
                value: type,
                items: const [
                  DropdownMenuItem(value: 'stock', child: Text('Stock')),
                  DropdownMenuItem(value: 'mutualfund', child: Text('Mutual Fund')),
                  DropdownMenuItem(value: 'fd', child: Text('Fixed Deposit')),
                  DropdownMenuItem(value: 'bond', child: Text('Bond')),
                  DropdownMenuItem(value: 'postoffice', child: Text('Post Office')),
                ],
                onChanged: (v) => setState(() => type = v ?? 'stock'),
                decoration: const InputDecoration(labelText: 'Asset Type'),
              ),
              TextFormField(controller: identifierCtrl, decoration: const InputDecoration(labelText: 'Identifier (ticker or code)'), validator: (v) => v == null || v.isEmpty ? 'Enter identifier' : null),
              TextFormField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Name')),
              TextFormField(controller: unitsCtrl, decoration: const InputDecoration(labelText: 'Units'), keyboardType: TextInputType.number),
              TextFormField(controller: priceCtrl, decoration: const InputDecoration(labelText: 'Purchase Price'), keyboardType: TextInputType.number),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: _save, child: const Text('Save')),
            ],
          ),
        ),
      ),
    );
  }
}
