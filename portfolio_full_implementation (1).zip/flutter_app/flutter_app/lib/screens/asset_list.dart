import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/local_db.dart';
import 'transactions_screen.dart';

class AssetList extends StatefulWidget {
  const AssetList({super.key});

  @override
  State<AssetList> createState() => _AssetListState();
}

class _AssetListState extends State<AssetList> {
  List<Map<String, dynamic>> assets = [];
  String query = '';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _load();
  }

  Future<void> _load() async {
    final db = Provider.of<LocalDb>(context, listen: false);
    final rows = await db.getAssets(query: query);
    setState(() {
      assets = rows;
    });
  }

  Future<void> _refresh() async {
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(padding: const EdgeInsets.symmetric(vertical:8.0), child: TextField(
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search assets...'),
          onChanged: (v) { query = v; _load(); },
        )),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _refresh,
            child: assets.isEmpty
              ? ListView(children: [Center(child: Padding(padding: EdgeInsets.all(20), child: Text('No assets yet. Tap + to add one.', style: TextStyle(color: Colors.grey))))])
              : ListView.separated(
                itemCount: assets.length,
                separatorBuilder: (_,__) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final a = assets[index];
                  return ListTile(
                    title: Text(a['name'] ?? a['identifier']),
                    subtitle: Text('${a['type']} • ${a['identifier']}'),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('${a['units'] ?? 0}'),
                      IconButton(icon: const Icon(Icons.chevron_right), onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (_) => TransactionsScreen(assetId: a['id'])));
                      })
                    ]),
                  );
                },
              ),
          ),
        ),
      ],
    );
  }
}
