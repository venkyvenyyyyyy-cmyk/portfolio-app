import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/local_db.dart';

class TransactionsScreen extends StatefulWidget {
  final int assetId;
  const TransactionsScreen({required this.assetId, super.key});

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  List<Map<String, dynamic>> txs = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _load();
  }

  Future<void> _load() async {
    final db = Provider.of<LocalDb>(context, listen: false);
    final rows = await db.getTransactions(widget.assetId);
    setState(() {
      txs = rows;
    });
  }

  Future<void> _addTx() async {
    final db = Provider.of<LocalDb>(context, listen: false);
    await db.insertTransaction(widget.assetId, DateTime.now().toIso8601String(), 'buy', 1, 0, 'manual');
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Transactions')),
      body: ListView.separated(
        itemCount: txs.length,
        separatorBuilder: (_,__) => const Divider(),
        itemBuilder: (context, index) {
          final t = txs[index];
          return ListTile(
            title: Text('${t['txType'] ?? t['tx_type'] ?? ''} ${t['units']} @ ${t['price']}'),
            subtitle: Text(t['txDate'] ?? t['tx_date'] ?? ''),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(onPressed: _addTx, child: const Icon(Icons.add)),
    );
  }
}
