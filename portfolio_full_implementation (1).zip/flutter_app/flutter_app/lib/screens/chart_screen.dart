import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class ChartScreen extends StatelessWidget {
  const ChartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final spots = [
      FlSpot(0, 100),
      FlSpot(1, 120),
      FlSpot(2, 115),
      FlSpot(3, 140),
      FlSpot(4, 138),
    ];
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: LineChart(
          LineChartData(
            minY: 90,
            maxY: 160,
            gridData: FlGridData(show: false),
            titlesData: FlTitlesData(show: false),
            lineBarsData: [
              LineChartBarData(spots: spots, isCurved: true, dotData: FlDotData(show: false)),
            ],
          ),
        ),
      ),
    );
  }
}
