import 'dart:async';
import 'api_service.dart';
import 'local_db.dart';

// SyncService: supports both REST push/pull and Firebase (placeholder)
class SyncService {
  Timer? _timer;
  final ApiService? api = null;

  void startPeriodicSync({int seconds = 300}) {
    _timer?.cancel();
    _timer = Timer.periodic(Duration(seconds: seconds), (_) async {
      try {
        // push local assets
        final db = LocalDb.instance;
        final local = await db.getAssets();
        // Here you would call ApiService.pushSync({'assets': local});
        // and then optionally pull remote changes and merge.
      } catch (e) {
        print('Sync error: \$e');
      }
    });
  }

  void stop() => _timer?.cancel();
}
