import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:async';

class LocalDb {
  static final LocalDb instance = LocalDb._();
  Database? _db;
  LocalDb._();

  Future<LocalDb> init() async {
    final p = await getDatabasesPath();
    final path = join(p, 'portfolio.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('CREATE TABLE assets (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, identifier TEXT, name TEXT, units REAL, purchasePrice REAL, purchaseDate TEXT, metadata TEXT)');
      await db.execute('CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, assetId INTEGER, txDate TEXT, txType TEXT, units REAL, price REAL, note TEXT)');
      await db.execute('CREATE TABLE price_cache (id INTEGER PRIMARY KEY AUTOINCREMENT, assetId INTEGER, identifier TEXT, fetchedAt TEXT, price REAL, raw TEXT)');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_assets_identifier ON assets(identifier)');
    });
    return this;
  }

  Future<int> insertAsset(Map<String, dynamic> a) async {
    return await _db!.insert('assets', a);
  }

  Future<List<Map<String, dynamic>>> getAssets({String? query}) async {
    if (query != null && query.isNotEmpty) {
      final rows = await _db!.query('assets', where: 'name LIKE ? OR identifier LIKE ?', whereArgs: ['%'+query+'%','%'+query+'%'], orderBy: 'id DESC');
      return rows;
    }
    final rows = await _db!.query('assets', orderBy: 'id DESC');
    return rows;
  }

  Future<int> insertTransaction(int assetId, String txDate, String txType, double units, double price, String note) async {
    return await _db!.insert('transactions', {'assetId': assetId, 'txDate': txDate, 'txType': txType, 'units': units, 'price': price, 'note': note});
  }

  Future<List<Map<String, dynamic>>> getTransactions(int assetId) async {
    final rows = await _db!.query('transactions', where: 'assetId = ?', whereArgs: [assetId], orderBy: 'txDate DESC');
    return rows;
  }

  Future<void> savePriceCache(int assetId, String identifier, double price, String raw) async {
    await _db!.insert('price_cache', {'asset_id': assetId, 'identifier': identifier, 'fetchedAt': DateTime.now().toIso8601String(), 'price': price, 'raw': raw});
  }

  Future<List<Map<String, dynamic>>> getLatestPrices() async {
    final rows = await _db!.rawQuery('SELECT identifier, price FROM price_cache WHERE id IN (SELECT MAX(id) FROM price_cache GROUP BY identifier)');
    return rows;
  }
}
