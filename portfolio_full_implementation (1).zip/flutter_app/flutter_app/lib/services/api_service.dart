import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl;
  ApiService({required this.baseUrl});

  Future<List<dynamic>> fetchAssets() async {
    final r = await http.get(Uri.parse('\$baseUrl/assets'));
    if (r.statusCode == 200) return jsonDecode(r.body);
    throw Exception('Failed to fetch assets');
  }

  Future<Map<String, dynamic>> fetchPrices(List<String> ids) async {
    final q = ids.join(',');
    final r = await http.get(Uri.parse('\$baseUrl/prices?ids=\$q'));
    if (r.statusCode == 200) return jsonDecode(r.body);
    throw Exception('Failed to fetch prices');
  }

  Future<void> pushSync(Map<String, dynamic> payload) async {
    final r = await http.post(Uri.parse('\$baseUrl/sync/push'), body: jsonEncode(payload), headers: {'Content-Type':'application/json'});
    if (r.statusCode != 200) throw Exception('Sync failed');
  }

  Future<Map<String, dynamic>> pullSync() async {
    final r = await http.get(Uri.parse('\$baseUrl/sync/pull'));
    if (r.statusCode == 200) return jsonDecode(r.body);
    throw Exception('Sync pull failed');
  }
}
