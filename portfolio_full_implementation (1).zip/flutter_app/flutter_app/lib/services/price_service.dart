import 'package:flutter/material.dart';
import 'api_service.dart';
import 'local_db.dart';

class PriceService {
  final String baseUrl;
  ApiService? api;
  PriceService({required this.baseUrl}) {
    api = ApiService(baseUrl: baseUrl);
  }

  Future<void> updateAllPrices(BuildContext context) async {
    final db = LocalDb.instance;
    // fetch assets
    final assets = await db.getAssets();
    final ids = assets.map((a) => a['identifier'].toString()).toSet().toList();
    if (ids.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No assets to update')));
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fetching prices...')));
    try {
      final res = await api!.fetchPrices(ids);
      // res is map identifier -> {price:..., fetched_at:...}
      for (final ident in res.keys) {
        final entry = res[ident];
        final price = (entry['price'] as num).toDouble();
        // find asset id(s)
        final matching = assets.where((a) => a['identifier'] == ident);
        for (final a in matching) {
          await db.savePriceCache(a['id'], ident, price, entry.toString());
        }
      }
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Prices updated')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Price update failed: \$e')));
    }
  }
}
