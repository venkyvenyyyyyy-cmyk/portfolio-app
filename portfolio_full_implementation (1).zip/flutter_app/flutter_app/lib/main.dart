import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/dashboard_screen.dart';
import 'services/local_db.dart';
import 'services/sync_service.dart';
import 'services/price_service.dart';
import 'package:workmanager/workmanager.dart';

void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    // Here you'd call the SyncService or PriceService to run periodic sync
    print('Background task: \$task running');
    return Future.value(true);
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Workmanager().initialize(callbackDispatcher, isInDebugMode: true);
  Workmanager().registerPeriodicTask('syncTask', 'periodicSync', frequency: const Duration(hours: 3));
  final db = await LocalDb.instance.init();
  final sync = SyncService();
  final priceService = PriceService(baseUrl: 'http://10.0.2.2:5000'); // emulator localhost
  sync.startPeriodicSync();
  runApp(PortfolioApp(db: db, sync: sync, priceService: priceService));
}

class PortfolioApp extends StatelessWidget {
  final LocalDb db;
  final SyncService sync;
  final PriceService priceService;
  const PortfolioApp({required this.db, required this.sync, required this.priceService, super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<LocalDb>.value(value: db),
        Provider<SyncService>.value(value: sync),
        Provider<PriceService>.value(value: priceService),
      ],
      child: MaterialApp(
        title: 'Portfolio Tracker',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
          useMaterial3: true,
          appBarTheme: AppBarTheme(elevation: 0, backgroundColor: Colors.white, foregroundColor: Colors.black),
        ),
        home: const DashboardScreen(),
      ),
    );
  }
}
