class Asset {
  int? id;
  String type;
  String identifier;
  String name;
  double units;
  double purchasePrice;
  String? purchaseDate;

  Asset({this.id, required this.type, required this.identifier, required this.name, this.units = 0, this.purchasePrice = 0, this.purchaseDate});

  factory Asset.fromMap(Map<String, dynamic> m) => Asset(
    id: m['id'],
    type: m['type'],
    identifier: m['identifier'],
    name: m['name'],
    units: (m['units'] ?? m['units'] ?? 0) + 0.0,
    purchasePrice: (m['purchasePrice'] ?? m['purchase_price'] ?? 0) + 0.0,
    purchaseDate: m['purchaseDate'] ?? m['purchase_date'],
  );
}
