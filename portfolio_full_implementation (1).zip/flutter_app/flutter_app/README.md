Flutter app (full) - Run:
  1. flutter pub get
  2. flutter run
Notes:
  - The PriceService points to http://10.0.2.2:5000 by default (use Android emulator). For a real device, set baseUrl to your LAN IP or public server.
  - Workmanager is configured for periodic tasks; change frequency as needed.
  - Firebase placeholders are included; add google-services.json and configure if you want cloud sync.
